<?php
	# mysql db constants DB_HOST, DB_USER, DB_PASS, DB_NAME
	const DB_HOST = 'localhost';
	const DB_USER = 'mydata1995';
	const DB_PASS = '@qNGbnI{+lh*';
	const DB_NAME = 'myloli';
?>